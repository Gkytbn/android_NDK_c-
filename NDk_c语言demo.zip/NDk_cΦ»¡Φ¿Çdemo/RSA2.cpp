
#include <jni.h>
#include <unistd.h>
#include "include/openssl/des.h"
#include "include/openssl/bio.h"
#include "include/openssl/evp.h"
#include "include/openssl/buffer.h"



int verifiedByRsaPublicKey(const string& publicKey, const string& signature, char* message) {
    char *chPublicKey = const_cast<char *>(publicKey.c_str());

    BIO* mem_bio = NULL;
    if ((mem_bio = BIO_new_mem_buf(chPublicKey, -1)) == NULL) {        //从字符串读取RSA公钥
        BIO_free(mem_bio);
        return -3;
    }
    EVP_PKEY *publicRsa = PEM_read_bio_PUBKEY(mem_bio, NULL, NULL, NULL);
    unsigned int slen = signature.length();

    EVP_MD_CTX md_ctx;
    EVP_VerifyInit(&md_ctx, EVP_sha1());
    EVP_VerifyUpdate(&md_ctx, message, strlen(message));
    int err = EVP_VerifyFinal(&md_ctx, (unsigned char*) signature.data(), slen, publicRsa);
    EVP_MD_CTX_cleanup(&md_ctx);
    EVP_PKEY_free(publicRsa);
    return err;
}
