package com.example.demojiami;


import android.os.Handler;
import android.util.Base64;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


public class ConnectionTask implements Runnable {

    private final static int timeOut = 20000;// http请求联网超时时间,默认时间20秒
    private String entity;
    private int responseCode;
    private String httpUrl;
    private InputStream is;
    private HttpURLConnection conn;// http连接对象
    private OutputStream outStream;// 输出流
    private String requestType;// 请求类型
    private String handler;
    private int callbackIndex;

    private byte[] bkey;

    static {

		System.loadLibrary("demo");
	}

    
 //   JNIEXPORT jstring JNICALL Java_com_example_demojiami_ConnectionTask_Encrypt(JNIEnv *env, jobject obj , jbyteArray Deskey,jbyteArray msg, jbyteArray key,
 //   		jint length,jbyteArray jbPublicKey);

	public native  String Encrypt( byte[] deskey,String  msg,
			   		int length);

	
	//JNIEXPORT jint JNICALL Java_com_example_demojiami_ConnectionTask_Decrypt(JNIEnv *env, jobject obj,  jbyteArray cipher, jbyteArray key, jbyteArray result,
	//		jint length);
	
	
	public native  int Decrypt( byte[]  src, byte[] deskey,byte[] result,int length);


    public ConnectionTask(byte[] bkey2, String handler, String requestType, String httpUrl,
                          int callbackIndex) {
        this.handler = handler;
        this.bkey=bkey2;
        this.requestType = requestType;
        this.httpUrl = httpUrl;
        this.callbackIndex = callbackIndex;

    }

   
  
    private String encrypTion(String src) throws Exception {

        
        
        String encrypt = Encrypt(bkey, src,src.getBytes().length);
 
        System.out.println("encrypt"+encrypt);
        return encrypt;

    }

    /**
     * 线程任务
     */
    public synchronized void run() {
        try {
            executeConnection(encrypTion(handler));
        } catch (SocketTimeoutException e) {
        } catch (IOException e) {
        } catch (InterruptedException e) {

        } catch (Exception e) {

        }
    }

    public static String getStringNoBlank(String str) {
        if (str != null && !"".equals(str)) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n");
            Matcher m = p.matcher(str);
            String strNoBlank = m.replaceAll("");
            return strNoBlank;
        } else {
            return str;
        }
    }

    public void executeConnection(String postBuffer) throws Exception {

        try {
     //     Log.e("发送报文:\n", entity);
            URL url = new URL(httpUrl);
            conn = (HttpURLConnection) url.openConnection();

            if (requestType.equals("POST")) {
                // 发送POST请求必须设置允许输出
                conn.setRequestProperty("content-type", "text/html");
                conn.setConnectTimeout(timeOut);
                conn.setRequestMethod("POST");
                conn.setReadTimeout(30000);
                conn.setConnectTimeout(30000);
                conn.setDoOutput(true);

                OutputStreamWriter out = new OutputStreamWriter(
                        conn.getOutputStream());
                out.write(postBuffer);
                out.flush();
                out.close();
            } else {
                conn.setRequestMethod("GET");
            }
            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                byte[] b = readDownDataEx(conn.getInputStream());
                String respDesc = new String(b, "utf-8");

              

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;

        } finally {
            try {
                if (is != null) {
                    is.close();
                }
                if (outStream != null) {
                    outStream.close();
                }
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (Exception ee) {
                ee.printStackTrace();
            } finally {
                is = null;
                outStream = null;
                conn = null;
            }
        }
    }

    public byte[] readDownDataEx(InputStream is) throws Exception {
        try {
            int contentLen = conn.getContentLength();
            String contentLength = conn.getHeaderField("Content-Length");
            if (contentLength != null && contentLength.trim().length() > 0) {
                int len = Integer.parseInt(contentLength.trim());
                if (len > contentLen) {
                    contentLen = len;
                }
            }
            byte[] byteReadArray = null;
            if (contentLen > 0) {
                int actual = 0;
                int bytesread = 0;
                byteReadArray = new byte[contentLen];
                while ((bytesread < contentLen) && (actual != -1)) {
                    actual = is.read(byteReadArray, bytesread, contentLen
                            - bytesread);
                    bytesread += actual;
                    Thread.sleep(10);
                }
            } else {
                ByteBuffer bv = ByteBuffer.allocate(1024 * 1024);
                int ch = -1;
                int bytesread = 0;
                while ((ch = is.read()) != -1) {
                    bv.put((byte) ch);
                    if (++bytesread % 1024 == 0) {
                        Thread.sleep(5);
                    }
                }
                if (bv.position() > 0) {
                    byteReadArray = new byte[bytesread + 1];
                    byte[] byteReadArrayEx = bv.array();
                    for (int i = 0; i <= bytesread; i++) {
                        byteReadArray[i] = byteReadArrayEx[i];
                    }
                    bv.clear();
                    bv = null;
                    // LogUtils.MyLogI("com.intelligent",new String(byteReadArray));
                }
            }
            return byteReadArray;
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 处理联网请求响应
     *
     * @throws InterruptedException
     */
    public void ReadDataResponse() throws Exception {
        // 设置读取超时时间
        conn.setReadTimeout(timeOut);
        // 获取网络输入流
        try {
            is = conn.getInputStream();
            byte[] b = new byte[is.available()];
            is.read(b);
            String respDesc = new String(b, "utf-8");

            
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            throw e;
        }
    }

    /**
     * 处理网络流写入本地
     *
     * @throws InterruptedException
     */
    public byte[] readDownData() throws Exception {
        try {
            int contentLen = conn.getContentLength();
            // 从返回头中获取返回长度
            String contentLength = conn.getHeaderField("Content-Length");
            if (contentLength != null && contentLength.trim().length() > 0) {
                // 没有断点
                int len = Integer.parseInt(contentLength.trim());
                if (len > contentLen) {
                    contentLen = len;
                }
            }
            byte[] byteReadArray = null;
            if (contentLen > 0) {
                int actual = 0;
                int bytesread = 0;
                byteReadArray = new byte[contentLen];
                while ((bytesread < contentLen) && (actual != -1)) {
                    actual = is.read(byteReadArray, bytesread, contentLen
                            - bytesread);
                    bytesread += actual;
                    // if (iCallBackStatus != null) {
                    // iCallBackStatus.onProgressBar(bytesread, contentLen);
                    // }
                    Thread.sleep(10);
                }
            } else {
                ByteBuffer bv = ByteBuffer.allocate(1024);
                int ch = -1;
                int bytesread = 0;
                while ((ch = is.read()) != -1) {
                    /*
                     * if(bv.position() >= bv.capacity()) { //bv. //bv.
					 * 
					 * }
					 */
                    bv.put((byte) ch);
                    if (++bytesread % 1024 == 0) {
                        // if (iCallBackStatus != null) {
                        // iCallBackStatus.onProgressBar(bytesread, -1);
                        // }
                        Thread.sleep(10);
                    }
                }
                if (bv.position() > 0) {
                    byteReadArray = bv.array();
                }
            }
            return byteReadArray;
        } catch (Exception e) {
            throw e;
        }
    }

}
