package com.example.demojiami;

import java.io.IOException;


import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	String initapp = "加密数据";
	//String initapp = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><msg service=\"initApp\" sysName=\"attach\" sign=\"RSA\" serialNumber=\"1469155679\" termId=\"star_open_esa\" termAdd=\"23.23,23.45\" termBrand=\"iPhone\" osVersion=\"iPhone OS 9.1\" appVersion=\"1.0.0\" >";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	}

	public void oncilck(View v) {

	 byte[] bkey;
	try {
		bkey = _3DesUtil.initKey();
	
		new Thread(new ConnectionTask(bkey,initapp, "POST", "http://88.88.88.88", 0)).start();

	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
