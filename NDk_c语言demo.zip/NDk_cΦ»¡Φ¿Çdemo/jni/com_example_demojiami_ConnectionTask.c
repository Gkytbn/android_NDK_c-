#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <openssllib/include/openssl/bio.h>
#include <openssllib/include/openssl/buffer.h>
#include <openssllib/include/openssl/des.h>
#include <openssllib/include/openssl/evp.h>
#include <openssllib/include/openssl/rsa.h>
#include <unistd.h>

#define TAG "myDemo-jni" // 这个是自定义的LOG的标识
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型

#define  PUBLIC_EXPONENT   RSA_F4
#define   MODULUS "9c847aae8aa567d36af169dbed35f42f9568d137067b30a204476897020e7d88914d1c03a671c62be4a05fbd645bd358b2ff38ad2e5166003414eb7b155301d1f6cacaa54260681073e1c02947379614e6b6123e5b35af50dc675f1c673565979cc4acb967976e209bad50d24ab38b6822198644de43874e4fb92714f6fd677d"
# ifdef  __cplusplus
extern "C" {
# endif

int Base64Encode_rsa(const char *encoded, int encodedLength, char *decoded) {
	return EVP_EncodeBlock((unsigned char*) decoded,
			(const unsigned char*) encoded, encodedLength);
}

/*Base64����*/
int Base64Decode_rsa(const char *encoded, int encodedLength, char *decoded) {
	return EVP_DecodeBlock((unsigned char*) decoded,
			(const unsigned char*) encoded, encodedLength);
}

/**
 * 字符串右补位函数 （超长会自动截断）
 * @dest 原字符串
 * @src 填充字符
 * @len 总长度
 * return 补位后字符串
 */
char *Rzero(char *dest, char *src, int len) {
	static char res[1024];
	memset(res, 0x00, sizeof(res));
	int dlen = strlen(dest);
	if (dlen >= len) {
		memcpy(res, dest, len);
	} else {
		memcpy(res, dest, dlen);
		while (dlen < len) {
			res[dlen] = src[0];
			dlen++;
		}
	}
	return (res);
}

unsigned char * encryptDES(const char *data, char *k);
unsigned char * decryptDES(const char *data, int data_len, char *k);

//jstring to char*
char* jstringTostring(JNIEnv* env, jstring jstr) {
	char* rtn = NULL;
	jclass clsstring = (*env)->FindClass(env, "java/lang/String");
	jstring strencode = (*env)->NewStringUTF(env, "utf-8");
	jmethodID mid = (*env)->GetMethodID(env, clsstring, "getBytes",
			"(Ljava/lang/String;)[B");
	jbyteArray barr = (jbyteArray)(*env)->CallObjectMethod(env, jstr, mid,
			strencode);
	jsize alen = (*env)->GetArrayLength(env, barr);
	jbyte* ba = (*env)->GetByteArrayElements(env, barr, JNI_FALSE);
	if (alen > 0) {
		rtn = (char*) malloc(alen + 1);
		memcpy(rtn, ba, alen);
		rtn[alen] = 0;
	}
	(*env)->ReleaseByteArrayElements(env, barr, ba, 0);
	LOGE("jstringTostring");
	return rtn;
}

/**
 * char数组转换成jbyteArray
 */
jbyteArray charArray2jbyteArray(JNIEnv *env, const unsigned char * array,
		jsize len) {

	jbyteArray jarrRV = (*env)->NewByteArray(env, len);
	jbyte *jby = (jbyte *) array;

	(*env)->SetByteArrayRegion(env, jarrRV, 0, len, jby);
	return jarrRV;
}

/**
 * jbyteArray转化成char*
 */
unsigned char * jbyteArray2charArray(JNIEnv*env, jbyteArray jbArray,
		jsize *jbArrayLen) {

	*jbArrayLen = (*env)->GetArrayLength(env, jbArray);
	unsigned char *array = (*env)->GetByteArrayElements(env, jbArray, 0);

#ifdef DEBUG
	if (strlen(array) != *jbArrayLen) {
		Logi("jbArrayLen-->%d", *jbArrayLen);
		int i = 0;
		for (i = 0; i < *jbArrayLen; i++) {
			Logi("0x%02x", *(array + i));
		}
	} else {
		Logi("jbArrayLen-->%d", *jbArrayLen);
		Logi("array[%d]-->%s", *jbArrayLen, array);
	}
#endif

	return array;
}

//unsigned char * encryptDES(const char *data, int * lenreturn, char *k);
//unsigned char * decryptDES(const char *data, int data_len, char *k);

static void openssl_base64_decode(char *encoded_bytes,
		unsigned char **decoded_bytes, size_t *decoded_length) {
	BIO *bioMem, *b64;
	size_t buffer_length;

	bioMem = BIO_new_mem_buf((void *) encoded_bytes, -1);
	b64 = BIO_new(BIO_f_base64());
	BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	bioMem = BIO_push(b64, bioMem);

	buffer_length = BIO_get_mem_data(bioMem, NULL);
	*decoded_bytes = malloc(buffer_length);
	if (decoded_bytes == NULL) {
		BIO_free_all(bioMem);
		*decoded_length = 0;
		return;
	}
	*decoded_length = BIO_read(bioMem, *decoded_bytes, buffer_length);
	BIO_free_all(bioMem);
}
/* Return NULL if failed, REMEMBER to free() */
static char *openssl_base64_encode(unsigned char *decoded_bytes,
		size_t decoded_length) {
	int x;
	BIO *bioMem, *b64;
	BUF_MEM *bufPtr;
	char *buff = NULL;

	b64 = BIO_new(BIO_f_base64());
	BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	bioMem = BIO_new(BIO_s_mem());
	b64 = BIO_push(b64, bioMem);

	BIO_write(b64, decoded_bytes, decoded_length);
	x = BIO_flush(b64);
	if (x < 1)
		goto END;

	BIO_get_mem_ptr(b64, &bufPtr);

	buff = (char *) malloc(bufPtr->length + 1);
	if (buff == NULL)
		goto END;
	memcpy(buff, bufPtr->data, bufPtr->length);
	buff[bufPtr->length] = 0;

	END: BIO_free_all(b64);
	return buff;
}

// 正常请求格式：BASE64(终端号)| BASE64(RSA(3DES密钥))| BASE64(3DES(报文原文))

jstring Java_com_example_demojiami_ConnectionTask_Encrypt(JNIEnv *env,
		jclass thiz, jbyteArray Deskey, jstring msg, jint length) {

	LOGE("jni识别开始");
	//第一端
	char * machid = "898520000011111";
	LOGE("jni识别开始%s", machid);

	int key_len2 = strlen(machid);
	char *one = openssl_base64_encode(machid, key_len2);

	LOGE("one=%s", one);

	jsize i4PlaintTextLen = (*env)->GetArrayLength(env, Deskey);
	jbyte * pKey = (jbyte*) (*env)->GetByteArrayElements(env, Deskey, 0);

//********************************************************************************************************

//
//
//	const char *pubkey = "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCchHquiqVn02rxadvtNfQvlWjR\nNwZ7MKIER2iXAg59iJFNHAOmccYr5KBfvWRb01iy/zitLlFmADQU63sVUwHR9srK\npUJgaBBz4cApRzeWFOa2Ej5bNa9Q3GdfHGc1ZZecxKy5Z5duIJutUNJKs4toIhmG\nRN5Dh05PuScU9v1nfQIDAQAB\n-----END PUBLIC KEY-----\n";
//
//
//
//	BIO *enc = NULL;
//		if ((enc = BIO_new_mem_buf(pubkey, -1)) == NULL)
//		{
//			/*printf("BIO_new_mem_buf failed!\n");*/
//			return (*env)->NewStringUTF(env,"-1");
//		}
//
//		/*解析公钥*/
//		RSA *rsa_pub = RSA_new();
//		rsa_pub = PEM_read_bio_RSA_PUBKEY(enc, NULL, 0, NULL);
//		if(rsa_pub == NULL)
//		{
//			/*printf("Unable to read public key!\n");*/
//			return (*env)->NewStringUTF(env,"-5");
//		}
//
//		int flen = RSA_size(rsa_pub);
//		unsigned char * pCipherText = (unsigned char *) malloc(flen+1);
//
//			  memset(pCipherText,0,flen+1);
//
//			  unsigned char t[flen];
//				memset(t, 0x00, sizeof(t));
//			 	strcpy(t, (unsigned char *) pKey);
//			  	unsigned char* gkbna = t;
//			 	LOGE("flen=%d", strlen(gkbna));
//
//		int ret = RSA_public_encrypt(flen - 11, gkbna, pCipherText, rsa_pub,
//			RSA_PKCS1_PADDING);
//		BIO_free_all(enc);
//		RSA_free(rsa_pub);

//***********************************************************rsa

	int ret, flen;
	BIGNUM *bnn, *bne;
	bnn = BN_new();
	bne = BN_new();
	BN_hex2bn(&bnn, MODULUS);
	BN_set_word(bne, PUBLIC_EXPONENT);

	RSA *r = RSA_new();
	r->n = bnn;
	r->e = bne;
	RSA_print_fp(stdout, r, 5);

	flen = RSA_size(r);
	LOGE("flen=%d", flen);
	//unsigned char cipherText[128] = { 0 };
//	unsigned char *pCipherText = cipherText;
	unsigned char * pCipherText = (unsigned char *) malloc(flen + 1);

	memset(pCipherText, 0, flen + 1);

//
	unsigned char t[128];
	memset(t, 0x00, sizeof(t));
	strcpy(t, (unsigned char *) pKey);
	unsigned char* gkbna = t;
	LOGE("flen=%d", strlen(gkbna));
////
////

//  char * gkbna=	Rzero( (unsigned char *) pKey,"0",strlen((unsigned char *) pKey));

	ret = RSA_public_encrypt(flen - 11, (unsigned char *) pKey, pCipherText, r,
	RSA_PKCS1_PADDING);
//	ret = RSA_public_encrypt(flen - 11, (unsigned char *) pKey, pCipherText, r,
//	RSA_PKCS1_PADDING);

	LOGE("ret=%d", ret);
	BN_clear_free(bnn);
	BN_clear_free(bne);
	RSA_free(r);

	LOGE("pCipherText16=%s", pCipherText);

//***********************************************************************************************************************

//********************************************************************************************************************

//	unsigned char *pCipherText;

//	PublicEncrypt((unsigned char *)pKey,pCipherText);

//***************************************************************************************************************
//第二段  BASE64(RSA(3DES密钥))

	char *two = openssl_base64_encode(pCipherText, strlen(pCipherText));

//	char *two ;
//	Base64Encode_rsa(pCipherText,strlen(pCipherText),two);
	LOGE("two=%s", two);

	if (pCipherText != NULL) {
		free(pCipherText);
		pCipherText = NULL;
	}

//*********************************************************************************RSA***
// 第三段内容

//
//	jbyte * pMsg = (jbyte*) (*env)->GetByteArrayElements(env, msg, 0);
//	jbyte * pKey2 = (jbyte*) (*env)->GetByteArrayElements(env, Deskey, 0);
//	//	jbyte * pKey = (jbyte*) (*env)->GetByteArrayElements(env, key, 0);
////		jbyte *pCipher = (jbyte*) (*env)->GetByteArrayElements(env, cipher, 0);
//
//		if (!pMsg || !pKey ) {
//			return (*env)->NewStringUTF(env, "null");
//		}
//		int flag = Encrypt(pMsg, pKey2, cipher, length); //���ܺ���
//		(*env)->ReleaseByteArrayElements(env, msg, pMsg, 0);

//	//	(*env)->ReleaseByteArrayElements(env, cipher, pCipher, 0);

//	int lenthaa = length;

	unsigned char *cipher;

	unsigned char *pmsg = jstringTostring(env, msg);

//	DES(pmsg,cipher,pKey,1);

//	unsigned char * des = (unsigned char *) malloc(1024+1);
//
//	  memset(des,0,1024+1);

	unsigned char des[1024];
	memset(des, 0x00, strlen(des));
	strcpy(des, pmsg);

//	Encrypt(pmsg,pKey,cipher,length);
	cipher = encryptDES(des, (char *) pKey);

//	if (des != NULL) {
//			free(des);
//			des = NULL;
//		}

	(*env)->ReleaseByteArrayElements(env, Deskey, pKey, 0);
	LOGE("pCipher=%s", pmsg);

//

//char *c_msg=jstringTostring(env,msg);
//unsigned char threea[1024 * 4] = { '\0' };
//unsigned char *threeb = threea;
//LOGE("three=%s", c_msg);
//	int flag = Encrypt(c_msg, pKey, threeb, strlen(c_msg)); //���ܺ���

	int key_len3 = strlen(cipher);
	char *three = openssl_base64_encode(cipher, key_len3);

//	if (cipher != NULL){
//		free(cipher);
//		cipher=NULL;
//	}
//	if (pmsg != NULL){
//		free(pmsg);
//		pmsg=NULL;
//	}
//	if (pCipherText != NULL){
//		free(pCipherText);
//		pCipherText=NULL;
//	}

	char * line = "|";
	LOGE("three=%s", three);
	char *result = malloc(
			strlen(one) + strlen(line) + strlen(two) + strlen(line)
					+ strlen(three) + 1); //+1 for the zero-terminator
//in real code you would check for errors in malloc here
//	if (result == NULL)
//		exit(1);

	strcpy(result, one);
	strcat(result, line);
	strcat(result, two);
	strcat(result, line);
	strcat(result, three);

	LOGE("result=%s", result);

	machid = NULL;
	one = NULL;
	two = NULL;
	three = NULL;
	cipher = NULL;
	three = NULL;
	line = NULL;
	pmsg = NULL;
	machid = NULL;

//		return NULL;
	return (*env)->NewStringUTF(env, result);
}
jint Java_com_example_demojiami_ConnectionTask_Decrypt(JNIEnv *env, jclass thiz,
		jbyteArray cipher, jbyteArray key, jbyteArray result, jint length) {
	jbyte * pCipher = (jbyte*) (*env)->GetByteArrayElements(env, cipher, 0);
	jbyte * pKey = (jbyte*) (*env)->GetByteArrayElements(env, key, 0);
	jbyte *pResult = (jbyte*) (*env)->GetByteArrayElements(env, result, 0);

	if (!pResult || !pKey || !pCipher) {
		return -1;
	}
	int flag = 0;
//	int flag = Decrypt(pCipher, pKey, pResult, length); //���ܺ���
	(*env)->ReleaseByteArrayElements(env, result, pResult, 0);
	(*env)->ReleaseByteArrayElements(env, key, pKey, 0);
	(*env)->ReleaseByteArrayElements(env, cipher, pCipher, 0);
//	return (*env)->NewStringUTF(env, two);
	return flag;
}

unsigned char * encryptDES(const char *data, char *k) {
	int docontinue = 1;
//  char *data = "gubojun"; /* 明文 */
	int data_len;
	int data_rest;
	unsigned char ch;
	unsigned char *src = NULL; /* 补齐后的明文 */
	unsigned char *dst = NULL; /* 解密后的明文 */
	int len;
	unsigned char tmp[8];
	unsigned char in[8];
	unsigned char out[8];

//	char *k = "12345678"; /* 原始密钥 */

	int key_len;
#define LEN_OF_KEY 24
	unsigned char key[LEN_OF_KEY]; /* 补齐后的密钥 */
	unsigned char block_key[9];
	DES_key_schedule ks, ks2, ks3;
	/* 构造补齐后的密钥 */
	key_len = strlen(k);
	memcpy(key, k, key_len);
	memset(key + key_len, 0x00, LEN_OF_KEY - key_len);
	/* 分析补齐明文所需空间及补齐填充数据 */
	data_len = strlen(data);
	data_rest = data_len % 8;
	len = data_len + (8 - data_rest);
	ch = 8 - data_rest;
	src = (unsigned char *) malloc(len);
	dst = (unsigned char *) malloc(len);
	if (NULL == src || NULL == dst) {
		docontinue = 0;
	}
	if (docontinue) {
		int count;
		int i;
		/* 构造补齐后的加密内容 */
		memset(src, 0, len);
		memcpy(src, data, data_len);
		memset(src + data_len, ch, 8 - data_rest);
		/* 密钥置换 */
		memset(block_key, 0, sizeof(block_key));
		memcpy(block_key, key + 0, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks);
		memcpy(block_key, key + 8, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks2);
		memcpy(block_key, key + 16, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks3);
		/* 循环加密/解密，每8字节一次 */
		count = len / 8;
		for (i = 0; i < count; i++) {
			memset(tmp, 0, 8);
			memset(in, 0, 8);
			memset(out, 0, 8);
			memcpy(tmp, src + 8 * i, 8);
			/* 加密 */
//
//			DES_ecb_encrypt((const_DES_cblock*) tmp, (DES_cblock*) in,
//					&schedule, DES_ENCRYPT);
			DES_ecb3_encrypt((const_DES_cblock*) tmp, (DES_cblock*) in, &ks,
					&ks2, &ks3,
					DES_ENCRYPT);

			/* 解密 */
//          DES_ecb3_encrypt((const_DES_cblock*) in, (DES_cblock*) out, &ks,
//                  &ks2, &ks3, DES_DECRYPT);
			/* 将解密的内容拷贝到解密后的明文 */
//          memcpy(dst + 8 * i, out, 8);
			memcpy(dst + 8 * i, in, 8);
		}
	}

//	*lenreturn = len;
	if (NULL != src) {
		free(src);
		src = NULL;
	}

	if (NULL != dst) {
		return dst;

	}

//	&ks=NULL;
//	&ks2=NULL;
//	&ks3=NULL;
//   &in=NULL;
//    &out=NULL;
//    &tmp=NULL;

	return dst;
}

unsigned char * decryptDES(const char *data, int data_len, char *k) {
	int docontinue = 1;
//  char *data = "gubojun"; /* 明文 */
//  int data_len;
	int data_rest;
	unsigned char ch;
	unsigned char *src = NULL; /* 补齐后的明文 */
	unsigned char *dst = NULL; /* 解密后的明文 */
	int len;
	unsigned char tmp[8];
	unsigned char in[8];
	unsigned char out[8];
//char *k = "12345678"; /* 原始密钥 */
	int key_len;
#define LEN_OF_KEY 24
	unsigned char key[LEN_OF_KEY]; /* 补齐后的密钥 */
	unsigned char block_key[9];
	DES_key_schedule ks, ks2, ks3;
	/* 构造补齐后的密钥 */
	key_len = strlen(k);
	memcpy(key, k, key_len);
	memset(key + key_len, 0x00, LEN_OF_KEY - key_len);
	/* 分析补齐明文所需空间及补齐填充数据 */
	data_rest = data_len % 8;
	len = data_len;
	src = (unsigned char *) malloc(len);
	dst = (unsigned char *) malloc(len);
	if (NULL == src || NULL == dst) {
		docontinue = 0;
	}
	if (docontinue) {
		int count;
		int i;
		/* 构造补齐后的加密内容 */
		memset(src, 0, len);
		memcpy(src, data, data_len);
		/* 密钥置换 */
		memset(block_key, 0, sizeof(block_key));
		memcpy(block_key, key + 0, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks);
		memcpy(block_key, key + 8, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks2);
		memcpy(block_key, key + 16, 8);
		DES_set_key_unchecked((const_DES_cblock*) block_key, &ks3);

		/* 循环加密/解密，每8字节一次 */
		count = len / 8;
		for (i = 0; i < count; i++) {
			memset(tmp, 0, 8);
			memset(out, 0, 8);
			memcpy(tmp, src + 8 * i, 8);
			/* 加密 */
//          DES_ecb3_encrypt((const_DES_cblock*) tmp, (DES_cblock*) in, &ks,
//                  &ks2, &ks3, DES_ENCRYPT);
			/* 解密 */
			DES_ecb3_encrypt((const_DES_cblock*) tmp, (DES_cblock*) out, &ks,
					&ks2, &ks3,
					DES_DECRYPT);
			/* 将解密的内容拷贝到解密后的明文 */
			memcpy(dst + 8 * i, out, 8);
		}
		for (i = 0; i < len; i++) {
			if (*(dst + i) < 9) {
				*(dst + i) = 0;
				break;
			}
		}
	}

	if (NULL != src) {
		free(src);
		src = NULL;
	}
	if (NULL != k) {
		free(k);
		k = NULL;
	}
	if (NULL != dst) {

		return dst;
	}

	return NULL;
}

#  ifdef  __cplusplus
}
#  endif
